﻿using KooliProjekt.Application.Features.Bookings;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace KooliProjekt.WebAPI.Controllers
{
    public class BookingsController : AdminApiControllerBase
    {
        private readonly IMediator _mediator;

        public BookingsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("get/{id}")]
        public async Task<IActionResult> Get(int id)
        {
            if(id <= 0)
            {
                return NotFound();
            }

            var query = new GetBookingQuery { Id = id };
            var booking = await _mediator.Send(query);

            if (booking == null)
            {
                return NotFound();
            }

            return Result(booking);
        }

        [HttpGet("list/{page}/{pageSize}")]
        public async Task<IActionResult> List(int page, int pageSize)
        {
            var query = new ListBookingQuery
            {
                Page = page,
                PageSize = pageSize
            };

            var bookings = await _mediator.Send(query);
            return Result(bookings);
        }

        [HttpPost("save")]
        public async Task<IActionResult> Save(SaveBookingCommand command)
        {
            var result = await _mediator.Send(command);
            return Result(result);
        }

        [HttpDelete("delete")]
        public async Task<IActionResult> Delete([FromBody] DeleteBookingCommand command)
        {
            var result = await _mediator.Send(command);
            return Result(result);
        }
    }
}
