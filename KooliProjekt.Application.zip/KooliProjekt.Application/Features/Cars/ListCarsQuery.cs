using KooliProjekt.Application.Dto;
using KooliProjekt.Application.Infrastructure.Paging;
using KooliProjekt.Application.Infrastructure.Results;
using MediatR;

namespace KooliProjekt.Application.Features.Cars
{
    public class ListCarsQuery : IRequest<OperationResult<PagedResult<CarDto>>>
    {
        public int Page { get; set; }
        public int PageSize { get; set; }
    }
}
