﻿using KooliProjekt.Application.Dto;
using KooliProjekt.Application.Infrastructure.Paging;
using KooliProjekt.Application.Infrastructure.Results;
using MediatR;

namespace KooliProjekt.Application.Features.Bookings
{
    public class ListBookingQuery : IRequest<OperationResult<PagedResult<BookingDto>>>
    {
        public int Page { get; set; }
        public int PageSize { get; set; }
    }
}
